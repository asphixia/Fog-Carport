package dat.backend.model.entities;

import java.sql.Timestamp;

public class Carport {

    private int ordre_id;
    private String username;
    private Timestamp ordredate;
    private int width;
    private int lenght;
    private int r_width;
    private int r_lenght;

    public Carport(int width, int lenght, int r_width, int r_lenght) {

        this.width = width;
        this.lenght = lenght;
        this.r_width = r_width;
        this.r_lenght = r_lenght;
    }

    public int getOrdre_id() {
        return ordre_id;
    }

    public void setOrdre_id(int ordre_id) {
        this.ordre_id = ordre_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Timestamp getOrdredate() {
        return ordredate;
    }

    public void setOrdredate(Timestamp ordredate) {
        this.ordredate = ordredate;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getLenght() {
        return lenght;
    }

    public void setLenght(int lenght) {
        this.lenght = lenght;
    }

    public int getR_width() {
        return r_width;
    }

    public void setR_width(int r_width) {
        this.r_width = r_width;
    }

    public int getR_lenght() {
        return r_lenght;
    }

    public void setR_lenght(int r_lenght) {
        this.r_lenght = r_lenght;
    }
}

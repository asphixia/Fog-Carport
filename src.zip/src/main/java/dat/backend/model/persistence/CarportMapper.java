package dat.backend.model.persistence;

import dat.backend.model.entities.Carport;
import dat.backend.model.entities.ShoppingCart;
import dat.backend.model.entities.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CarportMapper {

    public CarportMapper(ConnectionPool connectionPool) {
    }


    public static List<Carport> Carport(ConnectionPool connectionPool)
    {
        List<Carport> carportList = new ArrayList<>();

        String sql = "SELECT * FROM carport.ordres";

        try (Connection connection = connectionPool.getConnection()) {

            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    int ordre_id = rs.getInt("ordre_id");
                    String username = rs.getString("username");
                    Timestamp ordredate = rs.getTimestamp("ordredate");
                    int width = rs.getInt("width");
                    int length = rs.getInt("length");
                    int r_width = rs.getInt("r_width");
                    int r_length = rs.getInt("r_length");
                    Carport newCarport = new Carport(width, length, r_width, r_length);
                    carportList.add(newCarport);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return carportList;
    }

    public static int creatOrder(User user, ConnectionPool connectionPool) {
        String sql = "insert into carport.orders (username) value (?)";

        try (Connection connection = connectionPool.getConnection()) {
            try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, user.getUsername());
                ps.executeUpdate();
                ResultSet rs = ps.getGeneratedKeys();
                rs.next();
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static void insertOrderLines(int order_id, ShoppingCart cart, ConnectionPool connectionPool)
    {
        String sql = "insert into carport.ordre_lines (order_id,username,width,lengthe,r_width,r_lenght) value (?,?,?,?,?,?)";

        try (Connection connection = connectionPool.getConnection())
        {
            for (Carport carport : cart.getCarportList() )
            {
                try (PreparedStatement ps = connection.prepareStatement(sql))
                {
                    ps.setInt(1,carport.getOrdre_id());
                    ps.setString(2,carport.getUsername());
                    ps.setInt(3,carport.getWidth());
                    ps.setInt(4,carport.getLenght());
                    ps.setInt(5,carport.getR_width());
                    ps.setInt(6,carport.getR_lenght());
                    ps.executeUpdate();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void Carport(int width, int length, int r_width, int r_length, ConnectionPool connectionPool)
    {

    }
}

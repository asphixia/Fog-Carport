package dat.backend.control;

import dat.backend.model.entities.Materialer;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@WebServlet(name = "MaterialeMap", value = "/MaterialeMap")
public class MaterialeMap extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
       Map<Integer, Materialer> materialerMap = new HashMap<>();

       request.getServletContext().setAttribute("materialerMap",materialerMap);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
